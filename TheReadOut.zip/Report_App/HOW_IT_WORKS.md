# How The Read-Out Works

The Read-Out is a standalone report builder. It does not scan targets. It takes report inputs and builds a final deliverable.

## 1. Report Template

Upload the customer DOCX template. The app stores the active template locally here:

```text
report_templates/default_pentest_template.docx
```

No private template is bundled in the public download. Each user must upload their own template. If the customer template changes, upload the new one and generate again.

## 2. Source Reports

Upload one or more source DOCX reports. The app stores them here:

```text
report_templates/source_reports/
```

The app reads those reports, extracts report context and findings, deduplicates repeated findings, and includes them in the final report.

## 3. Evidence Screenshots

Upload screenshots or place them directly here:

```text
report_templates/evidence_screenshots/
```

Use finding-style names:

```text
H1.png
H1-1.png
H1-2.png
L1.png
M1.png
```

The prefix means severity and finding number:

- `C` = Critical
- `H` = High
- `M` = Medium
- `L` = Low
- `I` = Informational

## 4. HTML Report

`Open HTML Report` opens a browser preview. Use this to quickly check merged findings, affected URLs, retest steps, curl, and screenshots.

## 5. Final DOCX

`Download Final DOCX` builds and downloads the final Word report from the uploaded template, source reports, and screenshots.

## Clean Workflow

1. Upload the client template.
2. Upload all source reports.
3. Upload screenshots named by evidence number.
4. Open the HTML report to review.
5. Download the final DOCX.
