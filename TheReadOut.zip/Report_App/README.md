# The Read-Out v1.1

Standalone White Hat Labs report generator.

The Read-Out builds a final client report from:

- A user-uploaded DOCX report template
- One or more source DOCX reports
- Evidence screenshots named by finding number, such as `H1.png` or `L1-1.png`

It does not require the Pentest app, Burp, or a scanner to be running.

## Quick Start

```bash
pip install -r requirements.txt
python3 app.py
```

Open:

```text
http://localhost:5055
```

## Folders

```text
report_templates/source_reports/
report_templates/evidence_screenshots/
```

You can upload files through the browser UI, or place them directly in the folders above.

## Outputs

- `Open HTML Report` opens the merged report in the browser.
- `Download Final DOCX` downloads the final report built from the active template.

See `INSTALLATION.md` and `HOW_IT_WORKS.md` for setup and workflow details.
