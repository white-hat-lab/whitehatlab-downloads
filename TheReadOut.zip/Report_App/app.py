"""The Read-Out - standalone report builder."""
import hashlib
import os
import re
import uuid
from datetime import datetime, timezone

import uvicorn
from fastapi import FastAPI, Request, UploadFile, File
from fastapi.responses import HTMLResponse, JSONResponse, StreamingResponse
from fastapi.staticfiles import StaticFiles
from fastapi.templating import Jinja2Templates

from report_generator import generate_final_html_report, generate_final_template_report

APP_DIR = os.path.dirname(os.path.abspath(__file__))
REPORT_DIR = os.path.join(APP_DIR, "report_templates")
TEMPLATE_PATH = os.path.join(REPORT_DIR, "default_pentest_template.docx")
SOURCE_DIR = os.path.join(REPORT_DIR, "source_reports")
EVIDENCE_DIR = os.path.join(REPORT_DIR, "evidence_screenshots")
IMAGE_EXTS = {".png", ".jpg", ".jpeg"}

os.makedirs(SOURCE_DIR, exist_ok=True)
os.makedirs(EVIDENCE_DIR, exist_ok=True)

app = FastAPI(title="The Read-Out")
app.mount("/static", StaticFiles(directory=os.path.join(APP_DIR, "static")), name="static")
templates = Jinja2Templates(directory=os.path.join(APP_DIR, "templates"))


def _safe_filename(name, default="file.docx"):
    base = os.path.basename(name or default)
    base = re.sub(r"[^A-Za-z0-9._ -]+", "_", base).strip(" ._") or default
    return base[:150]


def _sha256(data):
    return hashlib.sha256(data).hexdigest()


def _validate_docx(data):
    if len(data or b"") < 100:
        return "DOCX file is empty."
    try:
        import io
        import zipfile
        with zipfile.ZipFile(io.BytesIO(data)) as zf:
            if "word/document.xml" not in zf.namelist():
                return "File is not a valid DOCX."
    except Exception as exc:
        return f"File is not a valid DOCX: {exc}"
    return ""


def _file_info(path):
    stat = os.stat(path)
    return {
        "name": os.path.basename(path),
        "path": path,
        "size": stat.st_size,
        "updated_at": datetime.fromtimestamp(stat.st_mtime, timezone.utc).isoformat(),
    }


def _list_source_reports():
    os.makedirs(SOURCE_DIR, exist_ok=True)
    reports = []
    for name in sorted(os.listdir(SOURCE_DIR)):
        if name.startswith("~$") or not name.lower().endswith(".docx"):
            continue
        path = os.path.join(SOURCE_DIR, name)
        if os.path.isfile(path):
            reports.append(_file_info(path))
    return reports


def _list_evidence():
    os.makedirs(EVIDENCE_DIR, exist_ok=True)
    images = []
    for name in sorted(os.listdir(EVIDENCE_DIR)):
        if os.path.splitext(name)[1].lower() not in IMAGE_EXTS:
            continue
        path = os.path.join(EVIDENCE_DIR, name)
        if os.path.isfile(path):
            info = _file_info(path)
            images.append(info)
    return images


def _save_source_report(data, filename):
    digest = _sha256(data)
    for report in _list_source_reports():
        try:
            with open(report["path"], "rb") as f:
                if _sha256(f.read()) == digest:
                    return {"ok": True, "duplicate": True, "report": report}
        except OSError:
            pass
    name = _safe_filename(filename, "source-report.docx")
    if not name.lower().endswith(".docx"):
        name += ".docx"
    final = f"{datetime.now(timezone.utc).strftime('%Y%m%d%H%M%S')}-{uuid.uuid4().hex[:8]}-{name}"
    path = os.path.join(SOURCE_DIR, final)
    with open(path, "wb") as f:
        f.write(data)
    return {"ok": True, "duplicate": False, "report": _file_info(path)}


def _scan_data():
    return {
        "id": "readout",
        "engagement_id": "readout",
        "target_url": "",
        "started_at": "",
        "ended_at": datetime.now(timezone.utc).isoformat(),
        "status": "final",
    }


@app.get("/", response_class=HTMLResponse)
async def index(request: Request):
    return templates.TemplateResponse(request, "index.html")


@app.get("/api/status")
async def status():
    template = _file_info(TEMPLATE_PATH) if os.path.exists(TEMPLATE_PATH) else None
    reports = _list_source_reports()
    evidence = _list_evidence()
    return {
        "ok": True,
        "template": template,
        "reports": reports,
        "evidence": evidence,
        "source_folder": SOURCE_DIR,
        "evidence_folder": EVIDENCE_DIR,
    }


@app.post("/api/template")
async def upload_template(file: UploadFile = File(...)):
    data = await file.read()
    err = _validate_docx(data)
    if err:
        return JSONResponse({"error": err}, 400)
    os.makedirs(REPORT_DIR, exist_ok=True)
    tmp = TEMPLATE_PATH + ".tmp"
    with open(tmp, "wb") as f:
        f.write(data)
    os.replace(tmp, TEMPLATE_PATH)
    return await status()


@app.post("/api/source-reports")
async def upload_reports(files: list[UploadFile] = File(...)):
    imported = 0
    duplicates = 0
    errors = []
    for file in files:
        data = await file.read()
        err = _validate_docx(data)
        if err:
            errors.append({"name": file.filename, "error": err})
            continue
        saved = _save_source_report(data, file.filename)
        if saved.get("duplicate"):
            duplicates += 1
        else:
            imported += 1
    result = await status()
    result.update({"imported": imported, "duplicates": duplicates, "errors": errors})
    return result


@app.post("/api/evidence")
async def upload_evidence(files: list[UploadFile] = File(...)):
    imported = 0
    errors = []
    for file in files:
        ext = os.path.splitext(file.filename or "")[1].lower()
        if ext not in IMAGE_EXTS:
            errors.append({"name": file.filename, "error": "Upload PNG or JPG evidence screenshots."})
            continue
        data = await file.read()
        name = _safe_filename(file.filename, f"evidence{ext}")
        path = os.path.join(EVIDENCE_DIR, name)
        with open(path, "wb") as f:
            f.write(data)
        imported += 1
    result = await status()
    result.update({"imported": imported, "errors": errors})
    return result


@app.delete("/api/source-reports")
async def clear_reports():
    removed = 0
    for report in _list_source_reports():
        os.remove(report["path"])
        removed += 1
    result = await status()
    result["removed"] = removed
    return result


@app.delete("/api/evidence")
async def clear_evidence():
    removed = 0
    for image in _list_evidence():
        os.remove(image["path"])
        removed += 1
    result = await status()
    result["removed"] = removed
    return result


@app.get("/api/final.docx")
async def final_docx():
    try:
        buf = generate_final_template_report(
            _scan_data(),
            [],
            proxy_entries=[],
            source_reports=_list_source_reports(),
            evidence_images=_list_evidence(),
        )
        return StreamingResponse(
            iter([buf.read()]),
            media_type="application/vnd.openxmlformats-officedocument.wordprocessingml.document",
            headers={"Content-Disposition": "attachment; filename=The-Read-Out-final-report.docx"},
        )
    except Exception as exc:
        return JSONResponse({"error": str(exc)}, 500)


@app.get("/api/final.html", response_class=HTMLResponse)
async def final_html():
    try:
        return generate_final_html_report(
            _scan_data(),
            [],
            proxy_entries=[],
            source_reports=_list_source_reports(),
            evidence_images=_list_evidence(),
        )
    except Exception as exc:
        return HTMLResponse(f"<h1>Report build failed</h1><pre>{exc}</pre>", status_code=500)


if __name__ == "__main__":
    port = int(os.environ.get("READOUT_PORT", "5055"))
    print(f"\n  The Read-Out running -> http://localhost:{port}\n")
    uvicorn.run(app, host="127.0.0.1", port=port, log_level="warning")
